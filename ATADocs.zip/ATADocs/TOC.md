# [Understand and explore](/understand/what-is-ata.md)
# [Plan and design](/plandesign/ata-capacity-planning.md)
# [Deploy and use](/deployuse/install-ata.md)
# [Troubleshoot](/troubleshoot/troubleshooting-ata-using-logs.md)
