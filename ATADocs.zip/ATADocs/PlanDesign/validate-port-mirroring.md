---
# required metadata

title: Validate Port Mirroring | Microsoft Advanced Threat Analytics
description: Describes how to validate that port mirroring is configured correctly
keywords:
author: rkarlin
manager: stevenpo
ms.date: 04/28/2016
ms.topic: get-started-article
ms.prod: identity-ata
ms.service: advanced-threat-analytics
ms.technology: security
ms.assetid: ebd41719-c91a-4fdd-bcab-2affa2a2cace

# optional metadata

#ROBOTS:
#audience:
#ms.devlang:
ms.reviewer: bennyl
ms.suite: ems
#ms.tgt_pltfrm:
#ms.custom:

---

# Validate Port Mirroring
The following steps walk you through the process for validating that port mirroring is properly configured. For ATA to work properly, the ATA Gateway must be able to see the traffic to and from the domain controller. The main data source used by ATA is deep packet inspection of the network traffic to and from your domain controllers. For ATA to see the network traffic, port mirroring needs to be configured. Port mirroring copies the traffic from one port (the source port) to another port (the destination port).

1.  Install [Microsoft Network Monitor 3.4](http://www.microsoft.com/download/details.aspx?id=4865) or another network sniffing tool.

    > [!IMPORTANT]
    > Do not install Microsoft Message Analyzer, or any other traffic capture software on the ATA Gateway.

2.  Open Network Monitor and create a new capture tab.

    1.  Select only the **Capture** network adapter or the network adapter that is connected to the switch port that is configured as the port mirroring destination.

    2.  Ensure that P-Mode is enabled.

    3.  Click **New Capture**.

        ![Create new capture tab image](media/ATA-Port-Mirroring-Capture.jpg)

3.  In the Display Filter window, enter the following filter: **KerberosV5 OR LDAP** and then click **Apply**.

    ![Apply KerberosV5 or LDAP filter image](media/ATA-Port-Mirroring-filter-settings.jpg)

4.  Click **Start** to start the capture session. If you do not see traffic to and from the domain controller, review your port mirroring configuration.

    > [!NOTE]
    > It is important to make sure you see traffic to and from the domain controllers.
    >
    > ![Start capture session image](media/ATA-Port-Mirroring-Capture-traffic.jpg)

5.  If you only see traffic in one direction, you should work with your networking or virtualization teams to help troubleshoot your port mirroring configuration.

## See Also

- [Configure port mirroring](configure-port-mirroring.md)
- [For support, check out our forum!](https://social.technet.microsoft.com/Forums/security/en-US/home?forum=mata)
